# Force Subscribe :
<p align="center"><a href="#"><img src="https://i.imgur.com/SmqQApH.jpg" width="250"></a></p> 
<h1 align="center"><b>@ForceSubscribeRobot</b></h1>
<h4 align="center">A Telegram Bot to force users to join a specific channel before sending messages in a group.</h4>

# 🤖 Demo :
Find it On Telegram As [@ForceSubscribeRobot](https://t.me/ForceSubscribeRoBot)

# 👨‍💻 Deploy:
### -Easy Way
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/DamienSoukara/FSub-Heroku/tree/master)

### -Normal Way
```python3
git clone https://github.com/DamienSoukara/FSub-Heroku
cd FSub-Heroku
pip3 install -r requirements.txt
python3 bot.py
```
# ⚙ Commands :

**Command :** ```/ForceSubscribe @Channel``` <br />
**Usage :** To Turn On And Setup The Channel.<br />

**Command :** ```/fsub Or /ForceSubscribe``` <br />
**Usage :** To Get The Current Settings. <br />

**Command :** ```/fsub clear``` <br />
**Usage :** To Unmute All Members Who Muted By Me. <br />

**Command :** ```/fsub on/off/disable``` <br />
**Usage :** To Turn Of ForceSubscribe.. <br />


## 👨‍💻 Credits :
Special Thanks To [@AdnanAhmad](https://github.com/viperadnan-git) & [@AmineSoukara](https://github.com/AmineSoukara) & [@Pyrogram](https://github.com/Pyrogram)
## 🖤 Original Repo : [Github@Viperadnan-Git](https://github.com/viperadnan-git/force-subscribe-telegram-bot)
